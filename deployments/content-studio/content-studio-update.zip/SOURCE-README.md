# Tutor’s Desk · Content Studio

A static, server-enforced content manager for SSC questions and **separate structured English board papers**. The default `index.html` is the new studio; the obsolete manual-JWT hosted implementation has been removed.

## Preview and tests

```sh
cd web-admin
npm ci --ignore-scripts
npm run vendor                      # pinned Supabase SDK, PDF.js, generated SQL bootstrap
npm test                            # shared validation / import tests
npx playwright install --with-deps chromium
npx playwright test                 # real-browser offline workflow tests
python3 -m http.server 4173 --bind 0.0.0.0
```

Open the server and choose **Explore an offline demo**. Demo records are intentionally labeled, memory-only and never sent to Supabase or AI. Closing/reloading clears them. Production counts come from the server, **not** the 5,279 APK assets.

## Production rollout — separate from code/CI delivery

1. Back up the Supabase database and existing `web-admin` deployment.
2. Apply `supabase/migrations/20260925000001_content_manager.sql` and the promotion tables included at the end of `database-update.sql` (`20260929000002_promotion_studio.sql`). Existing questions are grandfathered as published; new content defaults to draft. Existing admin membership is retained. These migrations do not create an administrator.
3. For a new installation, configure `question-figures` using `supabase/content_storage.sql`. Alternatively, `web-admin/schema.sql` is a generated **complete bootstrap** containing both. Do not use an older copy of the legacy schema: it lacks draft visibility restrictions.
4. An existing project owner grants administrator membership in `public.question_admins` using a verified account UUID in the server SQL console. Never expose a service-role key to the browser.
5. Deploy `supabase/functions/admin-content` for optional AI structuring/review. It verifies the caller’s authenticated user and administrator membership. Configure `GEMINI_API_KEY` as an Edge Function secret, not a frontend setting. Manual import works without it. The APK uses a **different** function, `mimi`: deploy `supabase/functions/mimi` as well for AI Tools/chat. Both use the same project-level `GEMINI_API_KEY`. For dashboard-only deployment, complete single-file bundles are available in `deployments/content-studio/`.
6. Upload the static `web-admin` directory, **including `english-upload.js`, `vendor/`, `catalog.json`, and the worker**, to your HTTPS hosting. Exclude `node_modules`, tests and reports. Configure `.mjs` as JavaScript. CSP is in `index.html`; a hosting-level equivalent is recommended. API traffic goes directly to the configured Supabase HTTPS project, never localhost.
7. Deploy `deployments/content-studio/bkash.ts` as the existing `bkash` Edge Function. It reads the active paid-plan offer server-side before initiating or verifying payment; it never trusts a browser price and remains the only code that grants `profiles.is_pro`.
8. Ship the companion APK. It reads active `paid_plan_offers`, `prizes`, `app_notifications` and `app_offer_ads`; notifications are an in-app feed, not Android system push. Popup ads are shown once per ad ID on each device, while subscription display values use active plan offers with the existing static plans as fallback.
9. Smoke-test with one first-paper draft and one second-paper draft: validate → review → publish → launch updated app online → select the board/year → generate PDF → archive → launch app online again. Sign in as a teacher and verify one sent notification, one active prize, one active popup ad and one active plan offer. Test offline after a successful sync.

No production migration, function deployment, hosting replacement or signing configuration is implied by passing tests.

## Two pipelines

- `questions` → paginated `QuestionSync` → `QuestionBank`: MCQ, SAQ, CQ only.
- `english_papers` → `EnglishPaperSync` → **actual `EnglishFirstSet` / `EnglishBoardSet`** → `EnglishPaperAdapter` → composer/PDF.
- `content_subjects` → cached `ContentCatalogSync` → subject list/chapter selectors. New subjects use custom counts; they do not acquire an invented official board pattern.

English schema v1 follows the existing book pattern (11 first-paper / 12 second-paper questions), not a claim about every future official exam. First paper has reading MCQs, comprehension, cloze, information transfer/summary, matching, rearrangement, poem/story questions and writing. Second paper has grammar and composition. They are not interchangeable.

## Workflow

- New or edited material is saved as **Draft**, including incomplete imports. Validation gates entry into Review and Published on the server.
- Editing published content returns it to draft; it is temporarily absent from the next public app snapshot until reapproved. Saved generated-paper snapshots remain printable.
- Publish one reviewed record or exactly the selected reviewed subset. Bulk operations are sequential, report partial completion and never silently overwrite a stale revision. IDs are immutable; use Duplicate for a new record.
- Archive sets `is_active=false`. Restore is reversible. Permanent deletion requires an archived record, confirmation and a downloaded JSON backup. Bulk archive/restore also downloads a backup first.
- Export all, a subject/chapter or the current selection as JSON. Selection is deliberately page-scoped (25 rows). Every export fetches all required server pages.
- Audit entries are generated by database triggers, readable by administrators and not browser-writable. Private-user question payloads are excluded from audit snapshots.

## Import and answer safety

- CSV headers: `id,subject,chapter,type,question,option_a,option_b,option_c,option_d,answer,explanation`. `B` means index 1. Missing/invalid answer → **-1**, never A. MCQ needs four distinct options, an explicit key and explanation before review.
- JSON supports row arrays, exported `{records:[...]}` and a single structured English record. Bulk imports always preview first and insert drafts; duplicate IDs do not overwrite existing content.
- English text detection conservatively extracts board/year and obvious section boundaries and retains the complete `data.source_text`. It does **not** claim to perfectly reconstruct tables or passages.
- **English Papers → Upload English Paper (PDF / Image)** accepts one PDF (up to 10 pages) or up to 10 JPG/PNG/WebP page photos, up to 20 MB total. A page preview and image ordering controls are available before drafting. PDF.js extracts selectable text locally.
- **Extract PDF / images with AI** sends resized page images to the authenticated `admin-content` function only after confirmation. This supports AI-assisted transcription of photos and scanned PDFs; it is not guaranteed OCR. Inspect every passage, table and question. Blurry/unreadable parts require manual repair. The function must be redeployed with the new attachment support; manual import does not need AI. Offline demo never sends images to the server.
- AI requests are limited to 10 JPEG/PNG/WebP pages and 3 MB combined decoded image bytes. SVGs, remote URLs, spoofed MIME signatures and oversized requests are rejected. Source originals remain in the browser session; saved drafts contain structured content and filenames, not binary originals. Generic question figures retain their separate upload workflow. English inline-image embedding is still not a model feature.
- Optional AI structuring is admin-only and produces reviewable drafts. English answers are forcibly null in AI responses. Generic keys require a source answer marker; source explanations/answers are retained only when found in the input. AI can still misassociate source fragments, so human review is mandatory.
- AI Review offers uncertain findings, not verified factual corrections; it never edits or publishes a record automatically.

## Offline, removals and limitations

A successful full paginated sync atomically replaces the cached remote snapshot; partial network failures retain the last successful cache. Archived/deleted IDs disappear on the next successful sync. Public ID-only server retirement markers also suppress matching bundled questions. Republish/restore clears the marker. With no network, the last downloaded content remains available. A new installation without an initial online sync still uses its original assets; already saved paper snapshots deliberately remain unchanged.

English answers are stored for source provenance and shown in admin review. They are **not newly integrated into the APK answer-key renderer**. The app consumes the actual structured question sections without invented keys. The admin browser print preview is a review layout, not pixel-identical to the app’s PDF pagination.

Storage cleanup reports missing and apparently unused server images. It cannot prove that an old APK, exported paper or external link no longer references an object. Deletion requires filename confirmation, a fresh server-reference check and an image backup; do not delete an object still used by a shipped asset. Storage object operations are not yet represented in the content-row audit history.

The local `tool/admin` bank writer uses the same `content-core.js` validation, but remains a developer-only asset tool, not an alternative hosted workflow or English publisher. Rebuilding and shipping an APK is still required for local asset changes.

## Security model

The supported Supabase browser SDK handles refresh with `persistSession:false`: access/refresh tokens stay in this tab’s memory. Reload requires sign-in. Old localStorage token entries are removed. Dynamic content is escaped; no user source text becomes HTML. The anon key is intentionally public; all meaningful privileges come from server RLS, triggers and Edge Function authentication. Do not host the local filesystem-writing admin on the public internet.
